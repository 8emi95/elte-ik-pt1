package rekakosa.progtech.closestshape.point;

public class Point2D {

	private double x;
	private double y;

	public Point2D(double first, double second) {
		x = first;
		y = second;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double distance(Point2D other) {
                
		return Math.sqrt(((x - other.getX())*(x - other.getX())) + ((y - other.getY())*(y - other.getY())));	
        }

	public double distanceFromLine(Point2D point1, Point2D point2) {
                Point2D normalVector = normalVector(point1, point2);
		double a = normalVector.getX();
		double b = normalVector.getY();
		double c = (-1) * ((a * point1.getX()) + (b * point1.getY()));
		return Math.abs((a*x + b*y + c)) / (Math.sqrt(a*a + b*b));
	}
        
	public boolean isPointInRange(Point2D point1, Point2D point2) {
                double[] equationOfSide = lineEquation(point1, point2);
               
                double c1 = (equationOfSide[0] * point1.getX()) + (equationOfSide[1] * point1.getY()); 
                double c2 = (equationOfSide[0] * point2.getX()) + (equationOfSide[1] * point2.getY());
                
                if (equationOfSide[1] != 0) {
                    equationOfSide[0] /= equationOfSide[1];
                    equationOfSide[1] /= equationOfSide[1];
                    c1 /= equationOfSide[1];
                    c2 /= equationOfSide[1];
                    
                }
                double[] perpendicularOfPoint1 = {(equationOfSide[1]), (-1) * equationOfSide[0], c1};  
                double[] perpendicularOfPoint2 = {(equationOfSide[1]), (-1) * equationOfSide[0], c2};
                
                if ((point1.getX() < point2.getX()) && (point1.getY() <= point2.getY())) {
                    flipInequalitySign(equationOfSide);
                    flipInequalitySign(perpendicularOfPoint2);
                } else if ((point1.getX() >= point2.getX()) && (point1.getY() < point2.getY())) {
                    flipInequalitySign(perpendicularOfPoint2);
                } else if ((point1.getX() > point2.getX()) && (point1.getY() >= point2.getY())) {
                    flipInequalitySign(perpendicularOfPoint1);
                } else if ((point1.getX() <= point2.getX()) && (point1.getY() > point2.getY())) {
                    flipInequalitySign(equationOfSide);
                    flipInequalitySign(perpendicularOfPoint1);
                }
            
                return ((equationOfSide[0] * y > equationOfSide[1] * x + equationOfSide[2]) && (perpendicularOfPoint1[0] * y > perpendicularOfPoint1[1] * x + perpendicularOfPoint1[2]) && (perpendicularOfPoint2[0] * y > perpendicularOfPoint2[1] * x + perpendicularOfPoint2[2]));
        }
        
        private void flipInequalitySign(double[] line) {
                for (int i = 0; i < line.length; ++i) {
                      line[i] = (-1) * line[i];
                }
        }
        
        private Point2D directionVector(Point2D point1, Point2D point2) {
                return new Point2D(point2.getX() - point1.getX(), point2.getY() - point1.getY());
        }
        
        private Point2D normalVector(Point2D point1, Point2D point2) {
                Point2D directionVector = directionVector(point1, point2);
                double normalX = directionVector.getY();
                double normalY = (-1) * directionVector.getX();
                return new Point2D(normalX, normalY);
            }
        
        private double[] lineEquation(Point2D point1, Point2D point2) {
                Point2D directionVector = directionVector(point1, point2);
                double coefficientOfY;
                double coefficientOfX;
                double constant;
                if (directionVector.getX() == 0) {
                    coefficientOfY = 0;
                    coefficientOfX = directionVector.getY();
                    constant = (-1) * directionVector.getY() * point1.getX(); 
                } else {
                    coefficientOfY = 1;
                    coefficientOfX = directionVector.getY()/directionVector.getX();
                    constant = point1.getY() - (directionVector.getY()/directionVector.getX() * point1.getX());
                }
                double[] coefficients = {coefficientOfY, coefficientOfX, constant};
                return coefficients;
            }

	public double minimalDistance(Point2D[] points) {
		double minimalDistance = distance(points[0]);
		for (Point2D actualPoint : points) {
			if (distance(actualPoint) < minimalDistance) {
				minimalDistance = distance(actualPoint);
			}
		}
		return minimalDistance;
	}

	public void rotateAboutPoint(Point2D point, double angle) {
		translateToOrigin(point.getX(), point.getY());
		rotateAboutOrigin(angle);
                translate(point.getX(), point.getY());
	}

	public void translateToOrigin(double dx, double dy) {
		x -= dx;
		y -= dy;
	}

	public void rotateAboutOrigin(double angle) {
                double tempX = x * Math.cos(Math.toRadians(angle)) - y * Math.sin(Math.toRadians(angle));
                double tempY = x * Math.sin(Math.toRadians(angle)) + y * Math.cos(Math.toRadians(angle));
                x = round(tempX);
                y = round(tempY);
	}
        
        public static double round(double coord) {
            return Math.round(coord * 10000.0) / 10000.0;
        }
        
	public void translate(double dx, double dy) {
		x += dx;
		y += dy;
	}
        
        @Override
        public String toString() {
            return String.format("(%.4f, %.4f)", getX(), getY());
        }
}

package szamlalo;

public class Keret 
{
    public static void main(String[] args) {
        new ÜresKeret();
    }   
}

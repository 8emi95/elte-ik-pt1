
public enum Nem {

    F�RFI, N�
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auto;

/**
 *
 * @author Dobreff András
 */
class Engine {
    private int speed = 0;

    int getSpeed() {
        return speed;
    }

    void setSpeed(int value) {
        this.speed = value;
    }
}

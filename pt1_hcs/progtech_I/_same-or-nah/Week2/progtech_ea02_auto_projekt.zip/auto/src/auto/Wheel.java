/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auto;

/**
 *
 * @author Dobreff András
 */
class Wheel {
    private int size;
    
    /**
     * @param diameter - diameter of Wheel
     */
    public Wheel(int diameter){
        this.size = diameter;
    }
}
